package com.company.Employee.service;
import java.util.List;

import com.company.Employee.model.Employee;

public interface EmployeeService {
    Iterable<Employee> findAll();

    List<Employee> search(String q);

    //Employee findById(int id);

    void save(Employee contact);
    
   
    List<Employee> findBySearchKey(String q);

    void delete(int id);

	Employee findById(int id);
}